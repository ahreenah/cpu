import * as c from  './constants.js'

class Line{
    label=undefined
    suffix=undefined
    command=''
    args=[]
    addr=0
    get size(){
        return 1 +this.args.length
    }
    get commandCode(){
        return c.commands[this.command.toLocaleUpperCase()]
    }
    get condition(){
        let lt = this.suffix=='lt' || this.suffix=='neq' || this.suffix=='lte'
        let gt = this.suffix&2
        let eq = this.suffix&1
        
    }
}

class Compiler{
    test=''
    lines=[]
    labels=[]

    parseLine(s){
        let l = new Line()
        s = s.split('#')[0]
        // while(s.indexOf('  '!=-1))
        //     s=s.replaceAll('  ',' ')
        let label_command = s.split(':')
        let restString = ''
        if(label_command.length==2){
            l.label=label_command[0]
            restString=label_command[1]
        }
        else{
            restString=label_command[0]
        }
        restString = restString.trim();
        console.log(restString)

        let parts = restString.split(' ')
        if(parts.length)
            l.command = parts[0]
        for(let i=1; i<parts.length; i++)
            l.args.push(parts[i])
        l.suffix = l.command.split('.')[1]
        l.command = l.command.split('.')[0]
        console.log(l.command.toLocaleUpperCase(), c.commands)
        if(!(c.commands[l.command.toLocaleUpperCase()] || c.commands[l.command.toLocaleUpperCase()]==0))
            throw new Error("Unknown command: "+l.command)
        if(l.args.length!=c.commandArgs[l.command.toLocaleUpperCase()])
            throw new Error(l.command+ " takes " +c.commandArgs[l.command.toLocaleUpperCase()]+" agruments ")
        this.lines.push(l)
        console.log(l)
    }
    computeAddress(){
        let addr = 0;
        for(let i of this.lines){
            i.addr=addr;
            addr+=i.size
        }
    }
    computeLabels(){
        for(let i of this.lines){
            if(i.label){
                if(this.labels[i.label])
                    throw new Error("Labels cannot be same")
                this.labels[i.label]=i.addr
            }
        }
    }
    computeJmpAddress(){
        for(let i of this.lines){
            if(i.command=='jmp'){
                if(!this.labels[i.args[0]])
                    throw new Error("No such label: "+i.args[0])
                i.args[0]=this.labels[i.args[0]]
            }
        }
    }
}

let c1 = new Compiler();
c1.parseLine('ctomi1 3')
c1.parseLine('nop')
c1.parseLine('x2: ctomi1 2')
c1.parseLine('x3: ctomi1.lt 2')
c1.parseLine('x1: ctomi1.lt 3')
c1.parseLine('jmp.lt x2')
c1.parseLine('jmp.gt x3')
c1.parseLine('jmp x1')
c1.computeAddress()
c1.computeLabels()
c1.computeJmpAddress()

console.log(c1.labels)
console.log(c1.lines.map(i=>({...i,size:i.size, commandCode:i.commandCode})))